#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:15:41 2018

@author: amazinger
"""
import numpy as np
from project_func import *
from cost_func import *

def compute_gradient(y, tx, w):
    """Compute the gradient."""
    N = y.shape[0]
    e = y - tx.dot(w)
    grad_L = -np.dot(tx.T,e)/N
    return grad_L

def least_squares_GD(y, tx, initial_w, max_iters, gamma):
    """Gradient descent algorithm."""
    w = initial_w
    for n_iter in range(max_iters):
        w = w - gamma*compute_gradient(y, tx, w)
    loss = compute_loss(y, tx, w)
    return w, loss

    
def compute_stoch_gradient(y, tx, w):
    """Compute a stochastic gradient from just few examples n and their corresponding y_n labels."""
    N = y.shape[0]
    e = y - tx.dot(w)
    batch_grad = -np.dot(tx.T,e)/N
    return batch_grad


def least_squares_SGD(y, tx, initial_w, batch_size , max_iters, gamma):
    """Stochastic gradient descent algorithm."""  
    w = initial_w
    for n_iter in range(max_iters):
        for minibatch_y, minibatch_tx in batch_iter(y, tx, batch_size):
            w = w - gamma*compute_gradient(minibatch_y, minibatch_tx, w)
    loss = compute_loss(y, tx, w)
    return w, loss

    
def least_squares(y, tx):
    """calculate the least squares solution."""
    N = y.shape[0]
    w_opt = np.dot(np.dot(np.linalg.inv(np.dot(tx.T,tx)),tx.T),y)
    e = y - np.dot(tx,w_opt)
    mse_opt = np.dot(e.T,e)/(2*N)
    return mse_opt, w_opt

def ridge_regression(y, tx, lambda_):
    """implement ridge regression."""
    assert lambda_ >= 0 and lambda_ <= 1, "incorrect lambda value (0 >= lambda >= 1)"

    N = len(y)
    lambdaI = (lambda_ * 2 * N) * np.eye(tx.shape[1])
    a = np.dot(tx.T,tx) + lambdaI
    b = np.dot(tx.T,y)

    w = np.linalg.solve(a, b)
    loss = compute_loss(y, tx, w)
    return w, loss
    
## logistic regression


def compute_log_likelihood(y, tx, w):
    
    l = np.sum(y*np.log(sigmoid(tx.dot(w)))+(1-y)*np.log(1-sigmoid(tx.dot(w))))
    
    return l
def compute_likelihood_gradient(y, tx, w):
    
    gradient = np.dot(tx.T,(y - sigmoid(tx.dot(w))))
    gradient = -gradient
    return gradient

def logistic_regression(y, tx, initial_w, max_iters, alpha):
# Define parameters to store w and loss
    ws = [initial_w]
    w = initial_w
    for n_iter in range(max_iters):
        
        # TODO: compute gradient and loss
        # TODO: update w by gradient
        w = w - alpha*compute_likelihood_gradient(y, tx, w)
        # store w and loss
        ws.append(w)
#        print("Gradient Descent({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
#              bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return ws[-1]

def stochastic_logistic_regression(y, tx, initial_w, batch_size, max_iters, alpha):
# Define parameters to store w and loss
    ws = [initial_w]
    w = initial_w
    for n_iter in range(max_iters):
        #print n_iter
        for minibatch_y, minibatch_tx in batch_iter(y, tx, batch_size):
            w = w - alpha*compute_likelihood_gradient(minibatch_y, minibatch_tx, w)
        # TODO: compute gradient and loss
        # TODO: update w by gradient
        # store w and loss
        ws.append(w)
#        print("Gradient Descent({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
#              bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return ws[-1]

def reg_logistic_regression(y, tx, lambda_, initial_w, max_iters, alpha):
# Define parameters to store w and loss
    ws = [initial_w]
    w = initial_w
    for n_iter in range(max_iters):
        #print n_iter
        # TODO: compute gradient and loss
        # TODO: update w by gradient
        w = w - alpha*(compute_likelihood_gradient(y, tx, w) + 2 * lambda_ * w)
        # store w and loss
        ws.append(w)
#        print("Gradient Descent({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
#              bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return ws[-1]