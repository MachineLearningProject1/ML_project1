#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:11:26 2018

@author: amazinger
"""

import numpy as np

def pca(dataMat,topNfeat=9999999):
    meanVals =np.mean(dataMat,axis=0)
    meanRemoved =dataMat - meanVals
    covMat =np.cov(meanRemoved,rowvar =0)
    eigvals,eigVects =np.linalg.eig(np.mat(covMat))
    eigValInd =np.argsort(eigvals)
    eigValInd =eigValInd[:-(topNfeat+1):-1]
    redEigVects =eigVects[:,eigValInd]
    lowDDataMat =meanRemoved * redEigVects
    reconMat =(lowDDataMat * redEigVects.T) +meanVals
    #return lowDDataMat,reconMat
    return np.array(lowDDataMat)

def merge_pca(x1, x2,topNfeat=9999999):
    dataMat = np.concatenate((x1, x2), axis=0)
    meanVals =np.mean(dataMat,axis=0)
    meanRemoved =dataMat - meanVals
    covMat =np.cov(meanRemoved,rowvar =0)
    eigvals,eigVects =np.linalg.eig(np.mat(covMat))
    eigValInd =np.argsort(eigvals)
    eigValInd =eigValInd[:-(topNfeat+1):-1]
    redEigVects =eigVects[:,eigValInd]
    lowDDataMat =meanRemoved * redEigVects
    reconMat =(lowDDataMat * redEigVects.T) +meanVals
    #return lowDDataMat,reconMat
    return np.array(lowDDataMat)[:x1.shape[0],:29], np.array(lowDDataMat)[x1.shape[0]:,:29]


def build_poly(x, root_max, degree_max):
    """polynomial basis functions for input data x, for j=0 up to j=degree."""
    # ***************************************************
    # INSERT YOUR CODE HERE
    # polynomial basis function: TODO
    # root_max >= 1
    poly_x = np.ones([x.shape[0]])
    for i in range(1,degree_max+1):
        poly_x = np.c_[poly_x, np.power(x,i)]
    for i in range(2,root_max+1):
        if 0 == 0:
            poly_x = np.c_[poly_x, np.power(np.abs(x),1./i)]
        else: poly_x = np.c_[poly_x, np.power(x,1./i)]
    poly_x = np.array(poly_x)
    # this function should return the matrix formed
    # by applying the polynomial basis to the input data
    return poly_x
    # ***************************************************
    raise NotImplementedError

def build_cross_mul(x):
    mul = np.ones([x.shape[0],2])
    N = x.shape[1]
    for i in range(1, N):
        mul = np.append(mul, x[:,i:]*x[:,:N-i], axis = 1)
#        for j in range(i+1, x.shape[1]):
#            print (np.array([x[:,i]*x[:,j]]).T).shape
#            mul = np.append(mul, np.array([x[:,i]*x[:,j]]).T,axis = 1)
    print mul.shape
    return mul[:,2:]

def build_log(x):
    return np.log(x - np.min(x)) + 1