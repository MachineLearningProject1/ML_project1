import numpy as np
from proj1_helpers import *
from project_func import *
from preprocessing import *
from cross_validation import *
from feature_engineering import *
from implementations import *

## load the data
path = '../data/train.csv'
label_train, input_train, ids = load_csv_data(path, sub_sample=True)
path = '../data/test.csv'
label_test, input_test, ids_test = load_csv_data(path, sub_sample=True)

del path

## data preprocessing
# replace invalid value
value_invalid = -999
x_valid = replace_invalid_mean(input_train,value_invalid)
x_test_valid = replace_invalid_mean(input_test,value_invalid)

## OR
x_valid, x_test_valid = replace_merge_mean(input_train, input_test, value_invalid)


## feature processing
# PCA (( merge or not???))
x_pca = pca(x_valid)
x_test_pca = pca(x_test_valid)

x_pca, x_test_pca = merge_pca(x_valid,x_test_valid)

del x_valid, x_test_valid

# poly feature and root 
poly_degree = 3
root_max = 3

polyx = build_poly(x_valid, root_max, poly_degree)
polyx_test = build_poly(x_test_valid, root_max, poly_degree)


# multi feature
mulx = build_cross_mul(x_valid)
mulx_test = build_cross_mul(x_test_valid)


# build log
x_log = build_log(x_valid)
x_test_log = build_log(x_test_valid)

# Combine
x_hd = np.append(polyx, mulx, axis = 1)
x_test_hd = np.append(polyx_test, mulx_test, axis = 1)

x_hd = np.append(x_hd, x_log, axis = 1)
x_test_hd = np.append(x_test_hd, x_test_log, axis = 1)

del x_pca, x_test_pca, polyx, polyx_test

# standardize
tx = standardize(x_hd[:,1:])
tx_test = standardize(x_test_hd[:,1:])
tx = np.append(np.ones([tx.shape[0],1]), tx, axis = 1)
tx_test = np.append(np.ones([tx_test.shape[0],1]), tx_test, axis = 1)

# OR
tx, tx_test = standardize_merge(x_hd[:,1:], x_test_hd[:,1:])
tx = np.append(np.ones([tx.shape[0],1]), tx, axis = 1)
tx_test = np.append(np.ones([tx_test.shape[0],1]), tx_test, axis = 1)
tx = np.delete(tx, 592, axis = 1)
tx_test = np.delete(tx_test, 592, axis = 1)
## delete feature
#tx = tx[:,[1,2,6,11,12,24]]
#tx_test = tx_test[:,[1,2,6,11,12,24]]

## logistic regression and prediction
alpha = 0.01
lambda_ = 0.01
max_iters = 1000

y = label_train
initial_w = np.ones([tx.shape[1]])
u = (1+y)/2.0

# ws = logistic_regression(u, tx, initial_w, max_iters, alpha)
ws = reg_logistic_regression(u, tx, lambda_, initial_w, max_iters, alpha)

y_estimated = predict_labels(tx, ws)
correct_rate = np.sum(np.abs(y_estimated - y))/2.0
correct_rate = 1 - correct_rate/y.shape

## Cross validation
seed = 6
k_fold = 6
alpha = 0.01
poly_degree = 3
#set_poly_degree = [1,3,5,7,9]
#set_alpha = [1., 0.1, 0.01, 0.001]
#set_lambda = [1., 0.1, 0.01, 0.001, 0.0001, 0.]
#set_root = [1,2,3,4,5,6,8,10,12,14]  ## 3 is the best
scores = []
for i, root in enumerate(set_root):
#for i, alpha in enumerate(set_alpha):
    print root
    tx = build_poly(x_std, root_max, poly_degree)
    initial_w = np.ones([tx.shape[1]])
    score = cross_validation_logistic(y, tx, lambda_, initial_w, max_iters, alpha, k_fold, seed)
    scores.append(score)
    
## Prediction
y_pre = predict_labels(tx_test, ws)

## generate the submission 
create_csv_submission(ids_test, y_pre, 'Submission_2210_11.csv')

