#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:37:05 2018

@author: amazinger
"""

import numpy as np