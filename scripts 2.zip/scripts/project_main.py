import numpy as np
from proj1_helpers import *
from project_func import *
from preprocessing import *
from cross_validation import *
from feature_engineering import *
from implementations import *

## load the data
path = '../data/train.csv'
label_train, input_train, ids = load_csv_data(path, sub_sample=True)
path = '../data/test.csv'
label_test, input_test, ids_test = load_csv_data(path, sub_sample=False)

del path       

## Cross validation

seed = 6
k_fold = 4
set_degree = range(3,10)
set_root = range(3,10) 
set_alpha = np.logspace(-5, 0, 10)
set_lambda = np.logspace(-5, 0, 10)
set_lambda = [0.01]
scores = np.zeros((len(set_degree), len(set_root), len(set_alpha), len(set_lambda)))
for i, degree in enumerate(set_degree):
    for j, root in enumerate(set_root):
        for k, alpha in enumerate(set_alpha):
            for l, lambda_ in enumerate(set_lambda):
                max_iters = 1000
                dele = method_fp("dele")
                dele.index = [4,5,6,12,26,27,28]
                pca = method_fp("pca")
                pca.merge = 1
                poly_mul_log = method_fp("poly_mul_log")
                poly_mul_log.poly_degree = degree
                poly_mul_log.root_max = root
                std = method_fp("std")
                std.merge = 1
                bias = method_fp("bias")
                ops = [std, poly_mul_log, std, bias]        
                score = cross_validation_logistic(label_train, input_train, lambda_, max_iters, alpha, k_fold, seed, ops)
                scores[i,j,k,l] = score
                print score
                
seed = 6
k_fold = 4
set_degree = range(3,10)
set_root = range(3,10)
set_lambda = np.logspace(-5, 0, 10)
scores = np.zeros((len(set_degree), len(set_root), len(set_alpha), len(set_lambda)))
for i, degree in enumerate(set_degree):
    for j, root in enumerate(set_root):
            for k, lambda_ in enumerate(set_lambda):
                dele = method_fp("dele")
                dele.index = [4,5,6,12,26,27,28]
                pca = method_fp("pca")
                pca.merge = 1
                poly_mul_log = method_fp("poly_mul_log")
                poly_mul_log.poly_degree = degree
                poly_mul_log.root_max = root
                std = method_fp("std")
                std.merge = 1
                bias = method_fp("bias")
                ops = [std, poly_mul_log, std, bias]        
                score = cross_validation_ridge(label_train, input_train, lambda_, k_fold, seed, ops)
                scores[i,j,k] = score
                print score
                
## Prediction
degree_opt = set_degree[np.unravel_index(np.argmax(scores, axis=None), scores.shape)[0]]
root_opt = set_root[np.unravel_index(np.argmax(scores, axis=None), scores.shape)[1]]
gamma_opt = set_alpha[np.unravel_index(np.argmax(scores, axis=None), scores.shape)[2]]
lambda_opt = set_lambda[np.unravel_index(np.argmax(scores, axis=None), scores.shape)[3]]

dele = method_fp("dele")
dele.index = [4,5,6,12,26,27,28]
pca = method_fp("pca")
pca.merge = 1
poly_mul_log = method_fp("poly_mul_log")
poly_mul_log.poly_degree = degree_opt
poly_mul_log.root_max = root_opt
std = method_fp("std")
std.merge = 1
bias = method_fp("bias")
ops = [std, poly_mul_log, bias]
 
y_tr = bool_label(label_train)
x_tr_valid, x_va_valid = preprocessing(input_train,input_test, method = "mean", merge = 1)
x_tr, x_te = feature_processing(x_tr_valid, x_va_valid, ops)
initial_w = np.zeros([x_tr.shape[1]])
w, loss = reg_logistic_regression(y_tr, x_tr, lambda_opt, initial_w, max_iters, gamma_opt)
y_estimated = predict_labels(x_tr, w)
accuracy = 1 - 0.5*np.mean(np.abs(y_estimated - label_train))
y_pre = predict_labels(x_te, w)
## generate the submission 
create_csv_submission(ids_test, y_pre, 'Submission_2210_12.csv')

