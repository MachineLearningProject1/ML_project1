#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:15:41 2018

@author: amazinger
"""
import numpy as np
from project_func import *
from cost_functions import *
from gradients import *

def least_squares_GD(y, tx, initial_w, max_iters, gamma):
    """Gradient descent algorithm."""
    w = initial_w
    for n_iter in range(max_iters):
        w = w - gamma*compute_gradient(y, tx, w, method = "mse")
    loss = compute_loss(y, tx, w, method = "mse")
    return w, loss

def least_squares_SGD(y, tx, initial_w, batch_size , max_iters, gamma):
    """Stochastic gradient descent algorithm."""  
    w = initial_w
    for n_iter in range(max_iters):
        for minibatch_y, minibatch_tx in batch_iter(y, tx, batch_size):
            w = w - gamma*compute_gradient(minibatch_y, minibatch_tx, w, method = "mse")
    loss = compute_loss(y, tx, w, method = "mse")
    return w, loss
    
def least_squares(y, tx):
    """calculate the least squares solution."""
    a = np.dot(tx.T,tx)
    b = np.dot(tx.T,y)
    w = np.linalg.solve(a, b)
    loss = compute_loss(y, tx, w, method = "mse")
    return w, loss

def ridge_regression(y, tx, lambda_):
    """implement ridge regression."""    
    N = len(y)
    lambdaI = (lambda_ * 2 * N) * np.eye(tx.shape[1])
    a = np.dot(tx.T,tx) + lambdaI
    b = np.dot(tx.T,y)
    w = np.linalg.solve(a, b)
    loss = compute_loss(y, tx, w, method = "mse")
    return w, loss
    
def logistic_regression(y, tx, initial_w, max_iters, gamma):
    ws = [initial_w]
    w = initial_w
    for n_iter in range(max_iters):
        w = w - gamma*compute_likelihood_gradient(y, tx, w, method = "log_likelihood")
        ws.append(w)
    loss = compute_loss(y, tx, w, method = "log_likelihood")
    return ws[-1], loss

def stochastic_logistic_regression(y, tx, initial_w, batch_size, max_iters, gamma):
    ws = [initial_w]
    w = initial_w
    for n_iter in range(max_iters):
        #print n_iter
        for minibatch_y, minibatch_tx in batch_iter(y, tx, batch_size):
            w = w - gamma*compute_gradient(minibatch_y, minibatch_tx, w, method = "log_likelihood")
        ws.append(w)
    loss = compute_loss(y, tx, w, method = "log_likelihood")
    return ws[-1], loss

def reg_logistic_regression(y, tx, lambda_, initial_w, max_iters, gamma):
    w = initial_w
    for n_iter in range(max_iters):
        w = w - gamma*(compute_gradient(y, tx, w, method = "log_likelihood") + 2 * lambda_ * w)
    loss = compute_loss(y, tx, w, method = "log_likelihood")
    return w, loss