#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:11:26 2018

@author: amazinger
"""

import numpy as np

def pca(dataMat,topNfeat=9999999):
    meanVals =np.mean(dataMat,axis=0)
    meanRemoved =dataMat - meanVals
    covMat =np.cov(meanRemoved,rowvar =0)
    eigvals,eigVects =np.linalg.eig(np.mat(covMat))
    eigValInd =np.argsort(eigvals)
    eigValInd =eigValInd[:-(topNfeat+1):-1]
    redEigVects =eigVects[:,eigValInd]
    lowDDataMat =meanRemoved * redEigVects
    reconMat =(lowDDataMat * redEigVects.T) +meanVals
    #return lowDDataMat,reconMat
    return np.array(lowDDataMat)

def merge_pca(x1, x2,topNfeat=9999999):
    dataMat = np.concatenate((x1, x2), axis=0)
    meanVals =np.mean(dataMat,axis=0)
    meanRemoved =dataMat - meanVals
    covMat =np.cov(meanRemoved,rowvar =0)
    eigvals,eigVects =np.linalg.eig(np.mat(covMat))
    eigValInd =np.argsort(eigvals)
    eigValInd =eigValInd[:-(topNfeat+1):-1]
    redEigVects =eigVects[:,eigValInd]
    lowDDataMat =meanRemoved * redEigVects
    reconMat =(lowDDataMat * redEigVects.T) +meanVals
    #return lowDDataMat,reconMat
    return np.array(lowDDataMat)[:x1.shape[0],:29], np.array(lowDDataMat)[x1.shape[0]:,:29]


def build_poly(x, root_max, degree_max):
    """polynomial basis functions for input data x, for j=0 up to j=degree."""
    # root_max >= 1
    poly_x = np.ones([x.shape[0]])
    for i in range(1,degree_max+1):
        poly_x = np.c_[poly_x, np.power(x,i)]
    for i in range(2,root_max+1):
        if (i % 2) == 0:
            poly_x = np.c_[poly_x, np.power(np.abs(x),1./i)]
        else: poly_x = np.c_[poly_x, ((x>0)*2.0-1)*np.power(np.abs(x),1./i)]
    poly_x = np.array(poly_x)
    return poly_x[:,1:]
    # ***************************************************
    raise NotImplementedError

def build_cross_mul(x):
    mul = np.ones([x.shape[0],2])
    N = x.shape[1]
    for i in range(1, N):
        mul = np.append(mul, x[:,i:]*x[:,:N-i], axis = 1)
#        for j in range(i+1, x.shape[1]):
#            print (np.array([x[:,i]*x[:,j]]).T).shape
#            mul = np.append(mul, np.array([x[:,i]*x[:,j]]).T,axis = 1)
    return mul[:,2:]

def build_log(x):
    return np.log(x - np.min(x)) + 1

class method_fp:
    def __init__(self, name):
        self.name = name


def standardize(x):
    ''' fill your code in here...
    '''
    centered_data = x - np.mean(x, axis=0)
    std_data = centered_data / np.std(centered_data, axis=0)
    
    return std_data

def standardize_merge(x1, x2):
    
    x = np.concatenate((x1, x2), axis=0)
    centered_data = x - np.mean(x, axis=0)
    std_data = centered_data / np.std(centered_data, axis=0)
    
    return std_data[:x1.shape[0]], std_data[x1.shape[0]:]

def feature_processing(x_tr, x_te, ops):
    for op in ops:
        if op.name == "dele":
            x_tr = x_tr[:,[1,2,6,11,12,24]]
            x_te = x_te[:,[1,2,6,11,12,24]]
            
        if op.name == "pca":
            if op.merge == 0:
                x_tr = pca(x_tr)
                x_te = pca(x_te)   
            if op.merge == 1:
                x_tr, x_te = merge_pca(x_tr,x_te)
                
        if op.name == "poly_mul_log":
            polyx_tr = build_poly(x_tr, op.root_max, op.poly_degree)
            polyx_te = build_poly(x_te, op.root_max, op.poly_degree)
            mulx_tr = build_cross_mul(x_tr)
            mulx_te = build_cross_mul(x_te)
#            logx_tr = build_log(x_tr)
#            logx_te = build_log(x_te)
#            x_tr = np.append(np.append(polyx_tr, mulx_tr, axis = 1), logx_tr, axis = 1)
#            x_te = np.append(np.append(polyx_te, mulx_te, axis = 1), logx_te, axis = 1)
            x_tr = np.append(polyx_tr, mulx_tr, axis = 1)
            x_te = np.append(polyx_te, mulx_te, axis = 1)
            
        if op.name == "std":
            if op.merge == 0:
                x_tr = standardize(x_tr)
                x_te = standardize(x_te) 
            if op.merge == 1:
                x_tr, x_te = standardize_merge(x_tr, x_te)
#                x_tr = np.append(np.ones([x_tr.shape[0],1]), x_tr, axis = 1)
#                x_te = np.append(np.ones([x_te.shape[0],1]), x_te, axis = 1)
                
        if op.name == "bias":
            x_tr = np.append(np.ones([x_tr.shape[0],1]), x_tr, axis = 1)
            x_te = np.append(np.ones([x_te.shape[0],1]), x_te, axis = 1)
            
    return x_tr, x_te