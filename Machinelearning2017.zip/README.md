# Machine Learning (CS433)

[Course @EPFL][ml-site], Fall semester, 2017-2018

Projects handouts available [here][ml-git-project]

Up-to-date github repository of the course available [here][ml-git]

[ml-site]: https://mlo.epfl.ch/page-146520.html
[ml-git]: https://github.com/epfml/ML_course
[ml-git-project]: https://github.com/epfml/ML_course/tree/b0479f4256c5060e8ecc9775e8890807da107d32/projects
