#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 27 09:57:41 2018

@author: amazinger
"""

def test(x):
    x = x + 1
    return x

x = 1
print x
test(x)
print x  # 函数输入变量不会被改变