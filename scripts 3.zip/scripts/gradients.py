#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 14:38:29 2018

@author: amazinger
"""

import numpy as np
from project_func import *

def compute_gradient(y, tx, w, method = "mse"):
    """Compute the gradient."""
    if method == "mse":
        N = y.shape[0]
        e = y - tx.dot(w)
        grad = -np.dot(tx.T,e)/N
        return grad
    if method == "log_likelihood":   # compute negative likelihood gradient
        grad = np.dot(tx.T,(y - sigmoid(tx.dot(w))))
        grad = -grad
        return grad