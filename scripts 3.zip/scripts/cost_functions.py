#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 23:37:05 2018

@author: amazinger
"""

import numpy as np
from project_func import *

def compute_loss(y, tx, w, method = "mse"):
    """Calculate the loss.

    You can calculate the loss using mse or mae.
    """
    if method == "mse":
        e = y - tx.dot(w)
        loss = 0.5*np.mean(e.T*e)
        return loss
    if method == "mae":
        e = y - tx.dot(w)
        loss = np.mean(np.abs(e))
        return loss
    if method == "log_likelihood":  # The negetive log likelihood, which we want to minimize
        loss = np.sum(y*np.log(sigmoid(tx.dot(w)))+(1-y)*np.log(1-sigmoid(tx.dot(w))))
        return loss
    
