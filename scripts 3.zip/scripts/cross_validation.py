#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 13:07:56 2018

@author: amazinger
"""
import numpy as np
from proj1_helpers import *
from project_func import *
from preprocessing import *
from implementations import *
from feature_engineering import *
def split_data(x, y, ratio, seed=1):
    """
    split the dataset based on the split ratio. If ratio is 0.8 
    you will have 80% of your data set dedicated to training 
    and the rest dedicated to testing
    """
    np.random.seed(seed)
    yx = zip(y,x)
    np.random.shuffle(yx)
    yx = np.array(yx)
    ind_cut = int(y.shape[0]*ratio)
    x_tr, x_te = yx[:ind_cut,1:], yx[ind_cut:,1:]
    y_tr, y_te = yx[:ind_cut,0], yx[ind_cut:,0]
    return x_tr, x_te, y_tr, y_te
    
def build_k_indices(y, k_fold, seed):
    """build k indices for k-fold."""
    num_row = y.shape[0]
    interval = int(num_row / k_fold)
    k_fold = int(k_fold)
    np.random.seed(seed)
    indices = np.random.permutation(num_row)
    k_indices = [indices[k * interval: (k + 1) * interval]
                 for k in range(k_fold)]
    return np.array(k_indices)

def cross_validation_logistic(y, x, lambda_, max_iters, alpha, k_fold, seed, ops):
    scores = []
    k_indices = build_k_indices(y, k_fold, seed)
    for k in k_indices:
        y_va = y[k]
        x_va = x[k]
        y_tr = y[k_indices[k_indices != k]]
        y_tr_ready = bool_label(y_tr)
        x_tr = x[k_indices[k_indices != k]]
        x_tr_valid, x_va_valid = preprocessing(x_tr,x_va, method = "mean", merge = 1)
        x_tr_ready, x_va_ready = feature_processing(x_tr_valid, x_va_valid, ops)
        initial_w = np.zeros([x_tr_ready.shape[1]])
        w, _ = reg_logistic_regression(y_tr_ready, x_tr_ready, lambda_, initial_w, max_iters, alpha)
        y_va_predict = predict_labels(x_va_ready,w)
        score = 1 - 0.5*np.mean(np.abs(y_va_predict - y_va))
        scores.append(score)
    return np.mean(scores) ## contain the mean and the std infrmations

def cross_validation_ridge(y, x, lambda_, k_fold, seed, ops, preprocess = True):
    scores = []
    k_indices = build_k_indices(y, k_fold, seed)
    for k in k_indices:
        y_va = y[k]
        x_va = x[k]
        y_tr = y[k_indices[k_indices != k]]
        y_tr_ready = bool_label(y_tr)
        x_tr = x[k_indices[k_indices != k]]
        if preprocess:
            x_tr_valid, x_va_valid = preprocessing(x_tr,x_va, method = "mean", merge = 1)
            x_tr_ready, x_va_ready = feature_processing(x_tr_valid, x_va_valid, ops)
        else: x_tr_ready, x_va_ready = feature_processing(x_tr, x_va, ops)
        w, _ = ridge_regression(y_tr_ready, x_tr_ready, lambda_)
        y_va_predict = predict_labels_ridge(x_va_ready,w)
        score = 1 - 0.5*np.mean(np.abs(y_va_predict - y_va))
        scores.append(score)
    return np.mean(scores) ## contain the mean and the std infrmations